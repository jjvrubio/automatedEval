/// <reference types="node" />
import { createHash } from "node:crypto";
import { writeFileSync } from "node:fs";
import { readHistoricalH36FileSync as readFileSync } from "./test-fixtures/h36/historical-read";
import { resolve } from "node:path";
import { act, createElement } from "react";
import { createRoot } from "react-dom/client";
import { MemoryRouter } from "react-router-dom";
import { afterEach, expect, it, vi } from "vitest";
import { App } from "@/app/App";
import { MockDataAdapter } from "@/demo/mock-adapter";
import { defaultDemoCatalogs, resolveDemo, type DemoCatalogs } from "./bootstrap";
import type { AppSnapshot, DemoAction, DemoEnableAction, ResolvedDemoRuntime } from "./contracts";
import archivePaths from "./test-fixtures/h34/archive-paths.json";
import * as vertical from "./vertical-evaluation";
import * as joint from "./cross-subject-evidence-admissibility";

// Historical S35 replay: archived S36 declarations retain the H35 wording.
// Current cumulative verification is H37; no provider/getSnapshot substitution.
Object.assign(globalThis, { IS_REACT_ACT_ENVIRONMENT: true });
afterEach(() => { vi.restoreAllMocks(); document.body.innerHTML = ""; });
const clone = <T,>(value: T): T => structuredClone(value);
const sha = (value: string | Buffer) => createHash("sha256").update(value).digest("hex");
const evidenceDir = resolve(process.cwd(), "../docs/evidence");
const ids = ["hospitality-family-adventure", "hospitality-family-adventure-costa"];
const selector = '[aria-label="Sujetos existentes"] .adventure-guest';
const stableDOM = (element: HTMLElement): string => {
  const copy = element.cloneNode(true) as HTMLElement;
  for (const node of copy.querySelectorAll("*")) {
    const attributes = [...node.attributes].map(({ name, value }) => [name, value]).sort(([a], [b]) => a.localeCompare(b));
    for (const { name } of [...node.attributes]) node.removeAttribute(name);
    for (const [name, value] of attributes) node.setAttribute(name, value);
  }
  return copy.innerHTML;
};
const withoutHuntName = (html: string): string => {
  const element = document.createElement("div"); element.innerHTML = html;
  element.querySelectorAll("#adventure-title").forEach((n) => { n.textContent = ""; });
  return stableDOM(element);
};
type FactFrame = {
  phase: string; input?: DemoAction | DemoEnableAction; snapshot: AppSnapshot;
  verticalCalls: Parameters<typeof vertical.evaluateVerticalEvidence>[];
  verticalResults: vertical.VerticalEvaluationState[];
  jointEvaluationCalls: Parameters<typeof joint.evaluateCrossSubjectEvidenceSufficiency>[];
  jointEvaluationResults: ReturnType<typeof joint.evaluateCrossSubjectEvidenceSufficiency>[];
};
type Frame = FactFrame & {
  homeDOM: string; supervisionDOM: string; activityDOM: string;
  headings: string[]; diagnostics: string[]; sessionRepresentation: string[];
};
const facts = ({ phase, input, snapshot, verticalCalls, verticalResults, jointEvaluationCalls, jointEvaluationResults }: FactFrame): FactFrame => ({
  phase, ...(input ? { input } : {}), snapshot, verticalCalls, verticalResults, jointEvaluationCalls, jointEvaluationResults,
});

it("H35 historical S35 replay: Experience.name supplies the GuestPerspective name across A/B and independent presentation perturbations", async () => {
  const baselineBytes = readFileSync(resolve(evidenceDir, "session-35/baseline.json"));
  const baseline = JSON.parse(baselineBytes.toString()) as { files: Record<string, string> };
  const projectRoot = resolve(process.cwd(), "../../..");
  const archived: Record<string, string> = archivePaths;
  for (const [path, hash] of Object.entries(baseline.files)) {
    expect(sha(readFileSync(resolve(projectRoot, archived[path] ?? path))), path).toBe(hash);
  }
  const appSource = readFileSync(resolve(process.cwd(), "src/app/App.tsx"), "utf8");
  expect(sha(appSource)).toBe(baseline.files["products/convercus-app/prototype/src/app/App.tsx"]);
  const productPaths = ["src/demo-factory/bootstrap.ts", "src/demo/mock-adapter.ts", "src/demo-factory/vertical-evaluation.ts"];
  const sourceHashes = Object.fromEntries(productPaths.map((p) => [p, sha(readFileSync(resolve(process.cwd(), p)))]));
  const oldRead = (p: string) => readFileSync(resolve(projectRoot, archived["products/convercus-app/prototype/" + p]), "utf8");
  const currentRead = (p: string) => readFileSync(resolve(process.cwd(), p), "utf8");
  const oldVertical = oldRead(productPaths[2]), currentVertical = currentRead(productPaths[2]);
  expect(currentVertical.slice(0, currentVertical.indexOf("export function projectGuestPerspective")))
    .toBe(oldVertical.slice(0, oldVertical.indexOf("export function projectGuestPerspective")));
  expect(currentVertical.slice(currentVertical.indexOf("export function projectSupervisionPerspective")))
    .toBe(oldVertical.slice(oldVertical.indexOf("export function projectSupervisionPerspective")));
  const oldAdapter = oldRead(productPaths[1]), currentAdapter = currentRead(productPaths[1]);
  expect(currentAdapter.slice(currentAdapter.indexOf("  async executeAction"))).toBe(oldAdapter.slice(oldAdapter.indexOf("  async executeAction")));
  expect(currentVertical).not.toContain('huntName: "Aventura Familiar"');
  const h34 = JSON.parse(readFileSync(resolve(evidenceDir, "session-34/execution-trace.json"), "utf8")) as {
    controls: Array<{ original: { frames: Frame[]; resetFrame: Frame } }>;
    genericRegression: Array<{ demoId: string; current: { frames: Frame[]; resetFrame: Frame } }>;
  };
  const evaluate = vi.spyOn(vertical, "evaluateVerticalEvidence");
  const cross = vi.spyOn(joint, "evaluateCrossSubjectEvidenceSufficiency");
  const clear = () => { evaluate.mockClear(); cross.mockClear(); };
  const run = async (runtime: ResolvedDemoRuntime) => {
    expect(Object.getPrototypeOf(runtime.provider)).toBe(MockDataAdapter.prototype);
    const initial = await runtime.provider.getSnapshot(), family = Boolean(initial.guestPerspective);
    const container = document.createElement("div"); document.body.append(container);
    const root = createRoot(container);
    const execute = vi.spyOn(runtime.provider, "executeAction");
    const resetSpy = vi.spyOn(runtime.provider, "reset");
    const mount = async (key = "initial") => {
      await act(async () => root.render(createElement(MemoryRouter, {
        key, initialEntries: [family ? "/?demo=" + runtime.manifest.demoId : "/system"],
      }, createElement(App, { runtime }))));
    };
    const clickText = async (text: string) => {
      const target = [...container.querySelectorAll<HTMLElement>("a,button")].find((n) => n.textContent === text);
      expect(target, text).toBeDefined(); await act(async () => target!.click());
    };
    const capture = async (phase: string, input?: DemoAction | DemoEnableAction): Promise<Frame> => {
      const snapshot = await runtime.provider.getSnapshot();
      const fact: FactFrame = { phase, ...(input ? { input } : {}), snapshot,
        verticalCalls: clone(evaluate.mock.calls), verticalResults: clone(evaluate.mock.results.map((r) => r.value)),
        jointEvaluationCalls: clone(cross.mock.calls), jointEvaluationResults: clone(cross.mock.results.map((r) => r.value)),
      };
      let homeDOM: string, supervisionDOM: string, headings: string[] = [], diagnostics: string[] = [], sessionRepresentation: string[] = [];
      if (family) {
        const guest = snapshot.guestPerspective!;
        expect(guest.huntName).toBe(runtime.experience!.name);
        expect(container.querySelector("#adventure-title")?.textContent).toBe(guest.huntName);
        expect(container.querySelector(".adventure-heading .eyebrow")?.textContent).toBe("Mi aventura · " + runtime.brand.name);
        expect(container.querySelector(".adventure-heading h1 + p")?.textContent ?? null).toBe(runtime.script?.experimentalIntroductoryFraming || null);
        expect(container.querySelector(".adventure-message")?.textContent).toBe(guest.message);
        expect(container.querySelector(".adventure-session")?.textContent).toBe(guest.sessionLabel);
        expect(container.querySelector(".adventure-account")?.textContent).toBe("Cuenta de " + snapshot.member.name);
        const cards = [...container.querySelectorAll(".adventure-guest")];
        expect(cards.map((n) => n.querySelector("h3")?.textContent)).toEqual(guest.subjects.map((s) => s.label));
        cards.forEach((n, i) => expect(n.querySelector("p")?.textContent).toContain(guest.subjects[i].status));
        homeDOM = stableDOM(container);
        await clickText("Supervisión");
        const supervision = snapshot.supervisionPerspective!;
        const subjects = [...container.querySelectorAll(selector)];
        headings = subjects.map((n) => n.querySelector("h2")!.textContent!);
        diagnostics = subjects.map((n) => n.querySelector("p")!.textContent!);
        expect(headings).toEqual(supervision.subjects.map((s) => s.id));
        diagnostics.forEach((text, i) => {
          const s = supervision.subjects[i];
          expect(text).toBe(`${s.id} · exists: ${String(s.exists)} · ${s.operationalState} · Evidence: ${s.evidenceCount}`);
        });
        expect([...container.querySelectorAll(".system-list dt")].map((n) => n.textContent)).toEqual([
          "Sujeto de sesión operativa", "Criterio K", "Evidence recibida", "Admisibilidad conjunta", "Suficiencia K", "Afirmación derivada",
        ]);
        expect([...container.querySelectorAll(".system-list dd")].map((n) => n.textContent)).toEqual([
          supervision.sessionSubjectRef, "A AND (B OR C)", String(supervision.evidence.length), supervision.jointAdmissibility, supervision.sufficiency, supervision.derivedClaim,
        ]);
        expect([...container.querySelectorAll(".adventure-evidence li")].map((n) => n.textContent)).toEqual(
          supervision.evidence.map((e) => `${e.id} · ${e.subjectRefs.join(", ")} · ${e.provenance}`),
        );
        sessionRepresentation = [...container.querySelectorAll('[aria-label="Evaluación compartida"] .system-list > div:first-child dt, [aria-label="Evaluación compartida"] .system-list > div:first-child dd')].map((n) => n.textContent!);
        expect(sessionRepresentation).toEqual(["Sujeto de sesión operativa", supervision.sessionSubjectRef]);
        supervisionDOM = stableDOM(container);
      } else {
        expect(snapshot.supervisionPerspective).toBeUndefined();
        expect(snapshot.guestPerspective).toBeUndefined();
        expect(container.querySelector(selector)).toBeNull();
        expect(container.querySelector("#supervision-title")).toBeNull();
        supervisionDOM = stableDOM(container);
        await clickText("Inicio"); homeDOM = stableDOM(container);
        expect(container.querySelector(".adventure-heading")).toBeNull();
      }
      await clickText("Actividad");
      const activityDOM = stableDOM(container);
      expect([...container.querySelectorAll(".activity-item h3")].map((n) => n.textContent)).toEqual(snapshot.activity.map((a) => a.title));
      if (family) await clickText("Mi aventura"); else await mount("after-" + phase);
      expect(await runtime.provider.getSnapshot()).toEqual(snapshot);
      expect(evaluate.mock.calls).toEqual(fact.verticalCalls);
      expect(cross.mock.calls).toEqual(fact.jointEvaluationCalls);
      return { ...fact, homeDOM, supervisionDOM, activityDOM, headings, diagnostics, sessionRepresentation };
    };
    try {
      clear(); await mount(); const frames: Frame[] = [await capture("initial")];
      for (let count = 0; count < 8; count++) {
        const available = frames.at(-1)!.snapshot.scenario?.availableActionId;
        if (!available) break;
        const step = runtime.script!.steps.find((s) => s.action.actionId === available)!;
        const button = container.querySelector<HTMLButtonElement>(family ? ".adventure-next button" : ".system-panel button");
        expect(button?.textContent).toBe(step.presenterLabel); expect(button?.disabled).toBe(false);
        clear(); await act(async () => button!.click());
        expect(execute.mock.calls.at(-1)?.[0]).toEqual(step.action);
        frames.push(await capture(available, step.action));
      }
      expect(frames.at(-1)!.snapshot.scenario?.availableActionId).toBeUndefined();
      clear();
      if (family) await clickText("Reiniciar aventura"); else { await runtime.provider.reset(); await mount("reset"); }
      const resetFrame = await capture("reset");
      expect(resetFrame.snapshot).toEqual(initial); expect(resetSpy).toHaveBeenCalledOnce();
      expect(resetFrame.homeDOM).toBe(frames[0].homeDOM);
      expect(resetFrame.supervisionDOM).toBe(frames[0].supervisionDOM);
      expect(resetFrame.activityDOM).toBe(frames[0].activityDOM);
      return { component: "CURRENT APP H35", demoId: runtime.manifest.demoId,
        experience: clone(runtime.experience), scenario: clone(runtime.scenario), script: clone(runtime.script), brand: clone(runtime.brand),
        frames, resetFrame, executedActions: clone(execute.mock.calls.map(([action]) => action)),
      };
    } finally { await act(async () => root.unmount()); container.remove(); execute.mockRestore(); resetSpy.mockRestore(); }
  };
  type Run = Awaited<ReturnType<typeof run>>;
  const all = (r: Run) => [...r.frames, r.resetFrame];
  const controls = [];
  type Mutation = (c: DemoCatalogs, m: DemoCatalogs["manifests"][string]) => void;
  const mutations: Record<string, Mutation> = {
    subjects: (c, m) => { c.scripts[m.scriptRef!].subjectPresentations!.forEach((s, i) => { s.label = "Participante " + (i === 0 ? "Alfa" : "Beta"); }); },
    account: (c, m) => { c.fixtures[m.fixtureRef].member.name = "Cuenta H35"; },
    brand: (c, m) => { c.brands[m.brandRef].name = "Marca H35"; },
    intro: (c, m) => { c.scripts[m.scriptRef!].experimentalIntroductoryFraming = "Introducción H35 independiente."; },
    journey: (c, m) => { c.scripts[m.scriptRef!].experimentalJourneyPresentations!.forEach((j) => { j.message = "Narrativa H35 independiente."; }); },
    experienceName: (c, m) => { c.experiences[c.scenarios[m.scenarioRef!].experienceRef].name = "Travesía compartida · H35"; },
    emptyName: (c, m) => { c.experiences[c.scenarios[m.scenarioRef!].experienceRef].name = ""; },
    experienceId: (c, m) => { c.experiences[c.scenarios[m.scenarioRef!].experienceRef].id = "opaque:experience/Z-42"; },
    presenter: (c, m) => { c.scripts[m.scriptRef!].steps.forEach((step) => { step.presenterLabel = "Acción H35 " + step.action.actionId; }); },
    activity: (c, m) => { c.scripts[m.scriptRef!].steps.forEach((s) => { if (s.activityPresentation) s.activityPresentation = { title: "Activity H35", description: "Descripción H35" }; }); },
  };
  for (const [index, demoId] of ids.entries()) {
    const make = (mutation?: Mutation) => { const c = clone(defaultDemoCatalogs); mutation?.(c, c.manifests[demoId]); return resolveDemo(demoId, c); };
    const original = await run(make());
    const old = h34.controls[index].original;
    expect(original.frames.map(facts)).toEqual(old.frames.map(facts));
    expect(facts(original.resetFrame)).toEqual(facts(old.resetFrame));
    expect(original.frames.map((f) => f.homeDOM)).toEqual(old.frames.map((f) => f.homeDOM));
    expect(original.resetFrame.homeDOM).toBe(old.resetFrame.homeDOM);
    expect(all(original).map((f) => f.supervisionDOM)).toEqual([...old.frames, old.resetFrame].map((f) => f.supervisionDOM));
    expect(all(original).map((f) => f.activityDOM)).toEqual([...old.frames, old.resetFrame].map((f) => f.activityDOM));
    const variants: Record<string, Run> = {};
    for (const [name, mutation] of Object.entries(mutations)) {
      const variant = await run(make(mutation));
      expect(variant.scenario).toEqual(original.scenario);
      const changesName = name === "experienceName" || name === "emptyName";
      expect(all(variant).map((f) => f.snapshot.guestPerspective!.huntName)).toEqual(Array.from({ length: 6 }, () => changesName ? variant.experience!.name : original.experience!.name));
      if (changesName || name === "experienceId") {
        expect(variant.script).toEqual(original.script); expect(variant.brand).toEqual(original.brand);
        expect({ ...variant.experience, name: "", id: "" }).toEqual({ ...original.experience, name: "", id: "" });
        if (changesName) expect(variant.experience!.id).toBe(original.experience!.id);
        if (name === "experienceId") expect(variant.experience!.name).toBe(original.experience!.name);
        expect(all(variant).map((f) => withoutHuntName(f.homeDOM))).toEqual(all(original).map((f) => withoutHuntName(f.homeDOM)));
        expect(all(variant).map((f) => f.supervisionDOM)).toEqual(all(original).map((f) => f.supervisionDOM));
        expect(all(variant).map((f) => f.activityDOM)).toEqual(all(original).map((f) => f.activityDOM));
      }
      expect(all(variant).map((f) => f.sessionRepresentation)).toEqual(all(original).map((f) => f.sessionRepresentation));
      expect(variant.executedActions).toEqual(original.executedActions);
      expect(all(variant).map((f) => f.headings)).toEqual(all(original).map((f) => f.headings));
      expect(all(variant).map((f) => f.snapshot.supervisionPerspective)).toEqual(all(original).map((f) => f.snapshot.supervisionPerspective));
      const mask = (frame: FactFrame) => {
        const f = clone(facts(frame)), s = f.snapshot;
        if (changesName) s.guestPerspective!.huntName = "";
        if (name === "subjects") s.guestPerspective!.subjects.forEach((x) => { x.label = ""; });
        if (name === "account") { s.member.name = ""; s.guestPerspective!.sessionLabel = ""; }
        if (name === "journey") s.guestPerspective!.message = "";
        if (name === "activity") s.activity.forEach((x) => { x.title = ""; x.description = ""; });
        return f;
      };
      expect(all(variant).map(mask)).toEqual(all(original).map(mask));
      if (name === "subjects") expect(variant.frames[0].snapshot.guestPerspective!.subjects.map((s) => s.label)).toEqual(["Participante Alfa", "Participante Beta"]);
      if (name === "account") expect(variant.frames[0].snapshot.guestPerspective!.sessionLabel).toBe("Cuenta de Cuenta H35");
      if (name === "brand" || name === "intro") expect(variant.frames[0].homeDOM).not.toBe(original.frames[0].homeDOM);
      if (name === "journey") expect(variant.frames[1].snapshot.guestPerspective!.message).toBe("Narrativa H35 independiente.");
      if (name === "activity") expect(variant.frames[2].snapshot.activity[0].title).toBe("Activity H35");
      variants[name] = variant;
    }
    // State, Evidence and evaluation change via public actions; the session reference stays fixed.
    expect(all(original).map((f) => f.sessionRepresentation)).toEqual(Array.from({ length: 6 }, () => ["Sujeto de sesión operativa", "subject-p1"]));
    expect(original.frames[0].snapshot.supervisionPerspective!.derivedClaim).toBe("not-produced");
    expect(original.frames.at(-1)!.snapshot.supervisionPerspective!.derivedClaim).toBe("established");
    expect(original.frames.map((f) => f.headings)).toEqual(Array.from({ length: 5 }, () => ["subject-p1", "subject-p2"]));
    expect(original.frames.map((f) => f.snapshot.supervisionPerspective!.subjects.map((s) => s.operationalState))).toEqual([
      ["not-enlisted", "not-enabled"], ["enabled", "not-enabled"], ["enabled", "not-enabled"], ["enabled", "enabled"], ["enabled", "enabled"],
    ]);
    expect(original.frames.map((f) => f.snapshot.supervisionPerspective!.subjects.map((s) => s.evidenceCount))).toEqual([[0, 0], [0, 0], [1, 0], [1, 0], [1, 1]]);
    controls.push({ composition: index === 0 ? "A" : "B", original, variants });
  }
  expect(all(controls[0].original).map((f) => f.headings)).toEqual(all(controls[1].original).map((f) => f.headings));
  expect(controls[0].original.frames[0].snapshot.guestPerspective!.subjects.map((s) => s.label)).not.toEqual(controls[1].original.frames[0].snapshot.guestPerspective!.subjects.map((s) => s.label));

  expect(all(controls[0].original).map((f) => f.sessionRepresentation)).toEqual(all(controls[1].original).map((f) => f.sessionRepresentation));

  expect(controls[0].original.scenario!.experienceRef).toBe(controls[1].original.scenario!.experienceRef);
  expect(controls[0].original.scenario!.id).not.toBe(controls[1].original.scenario!.id);
  expect(all(controls[0].original).map((f) => f.snapshot.guestPerspective!.huntName)).toEqual(all(controls[1].original).map((f) => f.snapshot.guestPerspective!.huntName));

  const generic = [];
  for (const old of h34.genericRegression) {
    const current = await run(resolveDemo(old.demoId));
    for (const field of ["homeDOM", "supervisionDOM", "activityDOM"] as const) expect(all(current).map((f) => f[field])).toEqual([...old.current.frames, old.current.resetFrame].map((f) => f[field]));
    expect(current.frames.map(facts)).toEqual(old.current.frames.map(facts));
    expect(facts(current.resetFrame)).toEqual(facts(old.current.resetFrame));
    generic.push({ demoId: old.demoId, current });
  }
  expect(generic.map((g) => g.demoId).sort()).toEqual(["hospitality-stay", "retail-baseline"]);
  const trace = {
    session: 35, recordedAt: new Date().toISOString(), verdict: "SUPPORTED WITH QUALIFICATION",
    method: "Historical S35 replay: archived S36 declarations, unchanged App/adapter/evaluators, immutable S34 facts and full DOM; not current H37 evidence",
    baselineSha256: sha(baselineBytes), appSha256: sha(appSource), sourceHashes,
    harnessSha256: sha(readFileSync(resolve(process.cwd(), "src/demo-factory/experience-sourced-guest-name-h35.test.ts"))),
    controls, genericRegression: generic,
    domIntegrationVerification: "EXECUTED", browserVisualValidation: "NOT EXECUTED",
    noNewRelation: "SUFFICIENT for semantic Experience name presentation within A/B",
    huntNameAuthority: "Experience.name; existing semantic correspondence; missing scalar transport supplied",
    presentationAuthorityStratification: "EVIDENCE STRENGTHENED / NOT PROMOTED", nextPressure: "OBSERVED / NOT SELECTED; H36 NOT OPENED",
  };
  if (process.env.H35_REPLAY_RECORD_PATH) writeFileSync(resolve(process.env.H35_REPLAY_RECORD_PATH), JSON.stringify(trace, null, 2) + "\n", { flag: "wx" });
}, 60000);

// S37: preserve old descriptions in this historical journey.
vi.mock("./artifacts", () => import("./test-fixtures/h36/artifacts"));
