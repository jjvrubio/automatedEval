/// <reference types="node" />
import { materialBaselineEntries } from "./test-fixtures/h38/material-baseline";
import { historicalH31Path } from "./test-fixtures/h31/source-path";
import { historicalH29Path } from "./test-fixtures/h29/source-path";
import { historicalH28Path } from "./test-fixtures/h28/source-path";
import { createHash } from "node:crypto";
import { writeFileSync } from "node:fs";
import { readHistoricalH34FileSync as readFileSync } from "./test-fixtures/h34/historical-read";
import { resolve } from "node:path";
import { afterEach, describe, expect, it, vi } from "vitest";
import { MockDataAdapter } from "@/demo/mock-adapter";
import { resolveDemo } from "./bootstrap";
import { historicalH24Path } from "./test-fixtures/h24/source-path";
import { historicalH26Path } from "./test-fixtures/h26/source-path";
import type { AppSnapshot, ContextReference, DemoAction } from "./contracts";
import * as vertical from "./vertical-evaluation";
import * as joint from "./cross-subject-evidence-admissibility";

// H25 changes Activity only. Preserve the original H23 snapshots and sources;
// H25 separately checks live context/evaluation regression with new Activity.
vi.mock("./bootstrap", () => import("./test-fixtures/h24/bootstrap"));
vi.mock("@/demo/mock-adapter", () => import("./test-fixtures/h24/mock-adapter"));
// H27 changes only subject labels; keep the original H23 projection here.
vi.mock("./vertical-evaluation", () => import("./test-fixtures/h26/vertical-evaluation"));

afterEach(() => vi.restoreAllMocks());
const sha256 = (value: string | Buffer) => createHash("sha256").update(value).digest("hex");
const root = resolve(process.cwd(), "../../..");
const prefix = "products/convercus-app/prototype/src/";
const baselinePath = resolve(process.cwd(), "../docs/evidence/session-23/baseline.json");
const baseline = JSON.parse(readFileSync(baselinePath, "utf8")) as {
  files: Record<string, string>;
  allowedChangedFiles: string[];
};
const h22 = JSON.parse(readFileSync(resolve(process.cwd(), "../docs/evidence/session-22/execution-trace.json"), "utf8")) as {
  positiveControls: Array<{ frames: Array<{ snapshot: AppSnapshot }>; reset: AppSnapshot }>;
  negativeControls: Array<{ frames: Array<{ snapshot: AppSnapshot }>; reset: AppSnapshot }>;
};
type JointArguments = Parameters<typeof joint.evaluateCrossSubjectEvidenceSufficiency>;

describe("H23 — Situated Evaluation Context Binding", () => {
  it("checks effective A/B inputs, contradictions and independent authority; stops on first material falsifier", async () => {
    for (const [path, hash] of materialBaselineEntries("H23", baseline.files)) {
      if (!baseline.allowedChangedFiles.includes(path)) {
        expect(sha256(readFileSync(resolve(root, historicalH31Path(historicalH29Path(historicalH28Path(historicalH26Path(historicalH24Path(path)))))))), path).toBe(hash);
      }
    }
    const archived = (file: string) => readFileSync(resolve(root, historicalH31Path(historicalH29Path(prefix + "demo-factory/test-fixtures/h22/" + file))), "utf8");
    const oldAdapter = archived("mock-adapter.ts");
    const oldVertical = archived("vertical-evaluation.ts");
    expect(sha256(oldAdapter)).toBe(baseline.files[prefix + "demo/mock-adapter.ts"]);
    expect(sha256(oldVertical)).toBe(baseline.files[prefix + "demo-factory/vertical-evaluation.ts"]);
    const currentAdapter = readFileSync(resolve(root, historicalH31Path(historicalH29Path(historicalH24Path(prefix + "demo/mock-adapter.ts")))), "utf8");
    expect(currentAdapter).toBe(oldAdapter.replace(
      "evaluateVerticalEvidence(this.evidence);",
      "evaluateVerticalEvidence(this.evidence, this.scenario.contexts);",
    ));
    const currentVertical = readFileSync(resolve(root, historicalH31Path(historicalH29Path(historicalH26Path(prefix + "demo-factory/vertical-evaluation.ts")))), "utf8");
    const projections = (source: string) => source.slice(source.indexOf("export function projectGuestPerspective"))
      .replace("export const verticalEvaluationContext = evaluationContext;", "").trim();
    expect(projections(currentVertical)).toBe(projections(oldVertical));

    const observations: Record<string, unknown> = {
      experiment: "H23 — Situated Evaluation Context Binding",
      baselineSha256: sha256(readFileSync(baselinePath)),
      applicationSha256: { adapter: sha256(currentAdapter), verticalEvaluation: sha256(currentVertical) },
      method: "Live public provider; transparent spies on original evaluator exports; archived H22 snapshots for regression; no browser",
    };
    const record = () => {
      if (process.env.H23_RECORD_PATH) {
        writeFileSync(resolve(process.env.H23_RECORD_PATH), JSON.stringify(observations, null, 2) + "\n");
      }
    };
    let phase = "A/B initial and H22 selection regression";
    try {
      const runtimes = [resolveDemo("hospitality-family-adventure"), resolveDemo("hospitality-family-adventure-costa")];
      expect(runtimes[0].provider).not.toBe(runtimes[1].provider);
      expect(runtimes[0].experience).toBe(runtimes[1].experience);
      expect(runtimes.map((r) => r.scenario!.id)).toEqual(["family-adventure", "family-adventure-costa"]);
      const initials: AppSnapshot[] = [];
      const frames: Array<Array<Record<string, unknown>>> = [[], []];
      observations.positiveControls = runtimes.map((r, i) => ({
        demoId: r.manifest.demoId, experienceRef: r.scenario!.experienceRef,
        scenario: r.scenario, frames: frames[i],
      }));
      for (const [i, runtime] of runtimes.entries()) {
        expect(Object.getPrototypeOf(runtime.provider)).toBe(MockDataAdapter.prototype);
        expect(runtime.scenario!.experienceRef).toBe("experience:family-adventure@1");
        const snapshot = await runtime.provider.getSnapshot();
        expect(snapshot).toEqual(h22.positiveControls[i].frames[0].snapshot);
        expect(snapshot.guestPerspective).toBeDefined();
        expect(snapshot.supervisionPerspective).toBeDefined();
        initials.push(snapshot);
        frames[i].push({ phase: "initial", snapshot });
      }
      const evaluate = vi.spyOn(vertical, "evaluateVerticalEvidence");
      const cross = vi.spyOn(joint, "evaluateCrossSubjectEvidenceSufficiency");
      const fullInputs: JointArguments[] = [];
      // Interleave the two providers to expose accidental shared mutable context.
      for (let stepIndex = 0; stepIndex < 4; stepIndex++) {
        for (const [i, runtime] of runtimes.entries()) {
          const action = structuredClone(runtime.script!.steps[stepIndex].action);
          phase = `${runtime.manifest.demoId}: ${action.actionId}`;
          evaluate.mockClear(); cross.mockClear();
          const snapshot = await runtime.provider.executeAction(action);
          expect(action).toEqual(runtime.script!.steps[stepIndex].action);
          expect(snapshot).toEqual(h22.positiveControls[i].frames[stepIndex + 1].snapshot);
          expect(evaluate).toHaveBeenCalledTimes("evidence" in action ? 1 : 0);
          expect(cross).toHaveBeenCalledTimes("evidence" in action ? 1 : 0);
          const frame: Record<string, unknown> = { phase: action.actionId, input: action, snapshot };
          if ("evidence" in action) {
            const verticalCalls = structuredClone(evaluate.mock.calls);
            const calls = structuredClone(cross.mock.calls);
            const results = structuredClone(cross.mock.results);
            const [facts, context, criterion, premise] = calls[0];
            const expected = i === 0
              ? { propertyRef: "aurora-resort", bookingRef: "AS-8842", stayRef: "stay-AS-8842" }
              : { propertyRef: "costa-clara-resort", bookingRef: "CC-205", stayRef: "stay-CC-205" };
            const forbidden = i === 0 ? /costa-clara|CC-205/ : /aurora-resort|AS-8842/;
            expect(JSON.stringify(calls[0])).not.toMatch(forbidden);
            expect(verticalCalls[0][1]).toEqual(runtime.scenario!.contexts);
            expect(verticalCalls[0][0].at(-1)).toEqual(action.evidence);
            expect(context).toEqual({ evaluationRef: "evaluation-family-adventure-1", huntRef: "hunt-family-adventure-1", ...expected });
            expect(facts).toHaveLength(stepIndex === 1 ? 1 : 2);
            for (const fact of facts) expect(fact).toMatchObject(expected);
            expect(facts.at(-1)).toMatchObject({ evidenceRef: action.evidence.id, subjectRef: stepIndex === 1 ? "subject-p1" : "subject-p2" });
            expect(criterion).toEqual({
              criterionRef: "criterion-family-adventure", authorityRef: "scenario-policy:family-adventure@1",
              scope: { huntRef: context.huntRef, propertyRef: expected.propertyRef },
              anchorMarkerRef: "marker-a", alternativeMarkerRefs: ["marker-b", "marker-c"],
            });
            expect(premise).toEqual({
              premiseRef: "premise-family-adventure-p1-p2@1", authorityRef: "fixture-policy:resort-family-adventure@1",
              scope: context, coveredSubjectRefs: ["subject-p1", "subject-p2"],
            });
            expect(results[0].type).toBe("return");
            expect(results[0].value.jointAdmissibility.reason).toBe(stepIndex === 1 ? "same-subject-control" : "applicable-authoritative-premise");
            // Explicit replay of the public H17 function with the captured real
            // arguments; this is not an interception of its lexical nested call.
            const jointReplay = joint.evaluateJointAdmissibility(facts, context, premise);
            expect(jointReplay).toEqual(results[0].value.jointAdmissibility);
            Object.assign(frame, { verticalCalls, jointEvaluationCalls: calls, jointEvaluationResults: results, jointReplay });
            if (stepIndex === 3) fullInputs[i] = calls[0];
          }
          frames[i].push(frame);
        }
      }
      for (const [i, runtime] of runtimes.entries()) {
        const snapshot = await runtime.provider.reset();
        expect(snapshot).toEqual(initials[i]);
        frames[i].push({ phase: "reset", snapshot });
      }

      phase = "H22 negative selection controls on live H23 code";
      const negatives: unknown[] = [];
      observations.negativeControls = negatives;
      for (const [i, demoId] of ["retail-baseline", "hospitality-stay"].entries()) {
        const runtime = resolveDemo(demoId);
        const initial = await runtime.provider.getSnapshot();
        expect(initial).toEqual(h22.negativeControls[i].frames[0].snapshot);
        expect(initial.guestPerspective).toBeUndefined();
        expect(initial.supervisionPerspective).toBeUndefined();
        const steps: unknown[] = [{ phase: "initial", snapshot: initial }];
        for (const [j, step] of (runtime.script?.steps ?? []).entries()) {
          evaluate.mockClear(); cross.mockClear();
          const snapshot = await runtime.provider.executeAction(step.action);
          expect(snapshot).toEqual(h22.negativeControls[i].frames[j + 1].snapshot);
          expect(evaluate).not.toHaveBeenCalled();
          expect(cross).not.toHaveBeenCalled();
          steps.push({ phase: step.action.actionId, snapshot, evaluationCalls: [] });
        }
        const reset = await runtime.provider.reset();
        expect(reset).toEqual(initial);
        negatives.push({ demoId, experienceRef: runtime.scenario?.experienceRef, frames: steps, reset });
      }

      const adversarial: unknown[] = [];
      observations.adversarialControls = adversarial;
      // Harness-only payloads; no new manifest or commercial demo registration.
      for (const [target, source] of [[1, 0], [0, 1]]) {
        phase = `adversarial mismatch: Scenario ${target === 1 ? "B" : "A"} / Evidence ${source === 1 ? "B" : "A"}`;
        const runtime = resolveDemo(runtimes[target].manifest.demoId);
        const mismatchFrames: unknown[] = [];
        for (const [index, step] of runtime.script!.steps.entries()) {
          const action = structuredClone(step.action);
          if ("evidence" in action) {
            action.evidence.contexts = structuredClone((runtimes[source].script!.steps[index].action as DemoAction).evidence.contexts);
          }
          const beforeInput = structuredClone(action);
          evaluate.mockClear(); cross.mockClear();
          const snapshot = await runtime.provider.executeAction(action);
          expect(action).toEqual(beforeInput);
          expect(snapshot.supervisionPerspective).toMatchObject({
            jointAdmissibility: "cannot-currently-establish", sufficiency: "not-attempted", derivedClaim: "not-produced",
          });
          expect(cross).not.toHaveBeenCalled();
          if ("evidence" in action) {
            expect(evaluate).toHaveBeenCalledOnce();
            expect(evaluate.mock.calls[0][0].at(-1)).toEqual(action.evidence);
            expect(evaluate.mock.calls[0][1]).toEqual(runtime.scenario!.contexts);
            expect(evaluate.mock.results[0].value.evidence).toEqual(evaluate.mock.calls[0][0]);
          }
          mismatchFrames.push({ phase: action.actionId, input: action, snapshot,
            verticalCalls: structuredClone(evaluate.mock.calls), verticalResults: structuredClone(evaluate.mock.results), jointEvaluationCalls: [] });
        }
        adversarial.push({ scenarioContexts: runtime.scenario!.contexts, frames: mismatchFrames });
      }

      phase = "missing, ambiguous or conflicting context / no automatic Evidence authority";
      const bEvidence = [1, 3].map((i) => structuredClone((runtimes[1].script!.steps[i].action as DemoAction).evidence));
      const bContexts = runtimes[1].scenario!.contexts;
      const incompleteControls: unknown[] = [];
      observations.incompleteContextControls = incompleteControls;
      const cases = [
        { name: "Evidence alone supplies no applicable context", evidence: bEvidence, contexts: [] },
        { name: "Scenario missing property", evidence: bEvidence, contexts: bContexts.filter(({ type }) => type !== "property") },
        { name: "Scenario ambiguous booking", evidence: bEvidence, contexts: [...bContexts, { type: "booking", id: "AS-8842" } as ContextReference] },
        { name: "Evidence missing stay", evidence: bEvidence.map((e) => ({ ...e, contexts: e.contexts.filter(({ type }) => type !== "stay") })), contexts: bContexts },
        { name: "Evidence ambiguous booking", evidence: bEvidence.map((e) => ({ ...e, contexts: [...e.contexts, { type: "booking", id: "AS-8842" } as ContextReference] })), contexts: bContexts },
        { name: "Evidence explicit conflicting property", evidence: bEvidence.map((e) => ({ ...e, contexts: [...e.contexts, { type: "property", id: "aurora-resort" } as ContextReference] })), contexts: bContexts },
      ];
      for (const control of cases) {
        cross.mockClear();
        const original = structuredClone(control);
        const result = vertical.evaluateVerticalEvidence(control.evidence, control.contexts);
        expect(result).toEqual({ evidence: control.evidence, jointAdmissibility: "cannot-currently-establish", sufficiency: "not-attempted" });
        expect(control).toEqual(original);
        expect(cross).not.toHaveBeenCalled();
        incompleteControls.push({ ...control, result, jointEvaluationCalls: [] });
      }

      phase = "authority remains a separate condition";
      const authorityControls: unknown[] = [];
      observations.authoritySeparationControls = authorityControls;
      for (const [i, args] of fullInputs.entries()) {
        const [facts, context, criterion, premise] = structuredClone(args);
        for (const [name, authority] of [
          ["no premise", undefined],
          ["premise with wrong context", { ...premise!, scope: { ...context, bookingRef: "unrelated-booking" } }],
          ["premise does not cover P2", { ...premise!, coveredSubjectRefs: ["subject-p1"] }],
        ] as const) {
          const input = structuredClone([facts, context, criterion, authority]);
          const result = joint.evaluateCrossSubjectEvidenceSufficiency(facts, context, criterion, authority);
          expect(result).toMatchObject({ jointAdmissibility: { determination: "cannot-currently-establish", reason: "no-applicable-authoritative-premise" }, sufficiency: { attempted: false } });
          expect([facts, context, criterion, authority]).toEqual(input);
          authorityControls.push({ composition: i === 0 ? "A" : "B", control: name, input, result });
        }
      }
      // Also exercise the actual integration with facts outside fixed P1/P2
      // coverage. This is a direct harness input, not a provider attribution edit.
      const p3Evidence = structuredClone(bEvidence);
      p3Evidence[1].subjects[0].id = "subject-p3";
      const uncovered = vertical.evaluateVerticalEvidence(p3Evidence, bContexts);
      expect(uncovered).toMatchObject({ jointAdmissibility: "cannot-currently-establish", sufficiency: "not-attempted" });
      expect(uncovered.claim).toBeUndefined();
      authorityControls.push({ control: "integration P1/P3 with fixed P1/P2 premise", evidence: p3Evidence, contexts: bContexts, result: uncovered });

      Object.assign(observations, {
        recordedAt: new Date().toISOString(), verdict: "SUPPORTED WITH QUALIFICATION",
        L1: "SITUATED BINDING EXECUTION-VERIFIED WITH SEPARATED A/B EVALUATION INPUTS",
        authoritySeparation: "PRESERVED under the existing explicitly assumed experimental premise",
        regressions: "A/B snapshots equal H22; live H22 positive/negative selection controls pass",
        outOfScope: { L3: "preserved / execution-confirmed", L4: "preserved / source-inspection only", L5: "preserved / execution-confirmed" },
        qualifications: ["Existing experimental premise explicitly situated, not productive authority accreditation", "Property supplied by Scenario when absent from Evidence, without modifying the fact", "No general binding architecture", "No historical H21/H22 revision", "No content repair or full Factory reuse"],
        nextMaterialPressure: "Authority provenance and missing factual property remain bounded assumptions; L3/L4/L5 remain; H24 NOT SELECTED",
      });
      record();
      console.info("H23: SUPPORTED WITH QUALIFICATION; L1 binding verified; mismatch undetermined; authority separation preserved.");
    } catch (error) {
      Object.assign(observations, { recordedAt: new Date().toISOString(), verdict: "FALSIFIED", stoppedAt: phase, error: String(error) });
      record();
      throw error;
    }
  });
});

// S35: historical replay only; frozen S34 sources fill unresolved archive paths.
// Existing earlier mocks retain precedence; current cumulative coverage is H35.
