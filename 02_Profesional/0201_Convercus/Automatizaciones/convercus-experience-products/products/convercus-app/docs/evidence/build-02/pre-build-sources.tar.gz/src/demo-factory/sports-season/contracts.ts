import type { BrandArtifact, DemoManifest, ResolvedCapability } from "../contracts";

// BUILD 01: local product constructs, experimental, not a TES contract.
export type SportsModality = "social" | "wellness";
export type EffortLevel = "suave" | "medio" | "intenso";

export interface SportsPerson {
  id: string;
  name: string;
  membershipStatus: "external" | "member";
  customerRelationship: "not-established";
}

export interface SportsEvent {
  id: string;
  seasonRef: string;
  discipline: "running" | "sailing" | "beach-volleyball";
  label: string;
  title: string;
  date: string;
  place: string;
  description: string;
  executable: boolean;
}

export interface SportsSeasonScenario {
  id: string;
  fixtureRef: string;
  person: SportsPerson;
  contrastPerson: SportsPerson;
  season: { id: string; title: string; dates: string; introduction: string };
  events: SportsEvent[];
  modalities: Array<{ value: SportsModality; label: string; description: string }>;
  efforts: Array<{ value: EffortLevel; label: string }>;
  badge: { id: string; title: string; reason: string };
  club: { name: string; invitation: string; description: string };
}

export interface SportsRegistration {
  registrationId: string;
  personRef: string;
  eventRef: string;
  selectedModality: SportsModality;
  status: "accepted";
}

interface SportsEvidenceBase {
  evidenceId: string;
  personRef: string;
  registrationRef: string;
  eventRef: string;
  occurredAt: string;
  simulation: true;
}

export type SportsEvidence =
  | (SportsEvidenceBase & { kind: "presence"; source: "simulated-check-in" })
  | (SportsEvidenceBase & { kind: "effort"; source: "participant-self-report"; level: EffortLevel });

export interface SportsBadge {
  badgeId: string;
  personRef: string;
  eventRef: string;
  registrationRef: string;
  ruleRef: string;
  supportingEvidenceRefs: string[];
  title: string;
  reason: string;
}

export interface CaptureOpportunity {
  id: string;
  personRef: string;
  registrationRef: string;
  badgeRef: string;
  kind: "club-invitation";
  status: "available";
}

export interface SportsSnapshot {
  scenario: SportsSeasonScenario;
  criterion: { ruleRef: string; explanation: string };
  registration?: SportsRegistration;
  evidence: SportsEvidence[];
  badge?: SportsBadge;
  opportunity?: CaptureOpportunity;
  // Operational demo position, never TES Progression/Completion.
  stage: "available" | "registered" | "presence-received" | "recognized";
}

interface SportsActionSubject { personRef: string; eventRef: string }
export type SportsAction =
  | (SportsActionSubject & { type: "sports-register"; selectedModality: string })
  | (SportsActionSubject & { type: "sports-check-in"; registrationRef: string })
  | (SportsActionSubject & { type: "sports-effort"; registrationRef: string; level: string });

export interface SportsProvider {
  getSnapshot(): Promise<SportsSnapshot>;
  executeAction(action: SportsAction): Promise<SportsSnapshot>;
  reset(): Promise<SportsSnapshot>;
}

export interface SportsSeasonResolvedRuntime {
  kind: "sports-season";
  manifest: DemoManifest;
  brand: BrandArtifact;
  scenario: SportsSeasonScenario;
  provider: SportsProvider;
  capabilities: ResolvedCapability[];
}
