import type { EffortLevel, SportsAction, SportsBadge, SportsEvidence, SportsModality, SportsProvider, SportsRegistration, SportsSeasonScenario, SportsSnapshot } from "./contracts";

export const sportsBadgeRuleRef = "sports-season:accepted-registration-presence-effort@1";
const modalities: readonly string[] = ["social", "wellness"];
const efforts: readonly string[] = ["suave", "medio", "intenso"];

// LOCAL / EXPERIMENTAL / NOT PROMOTED. No TES or hotel evaluator dependency.
function recognize(
  registration: SportsRegistration,
  evidence: SportsEvidence[],
  scenario: SportsSeasonScenario,
): SportsBadge | undefined {
  const belongs = (item: SportsEvidence) => item.personRef === registration.personRef &&
    item.eventRef === registration.eventRef && item.registrationRef === registration.registrationId;
  const presence = evidence.find((item) => belongs(item) && item.kind === "presence" && item.source === "simulated-check-in");
  const effort = evidence.find((item) => belongs(item) && item.kind === "effort" &&
    item.source === "participant-self-report" && efforts.includes(item.level));
  if (registration.status !== "accepted" || !presence || !effort) return undefined;
  return {
    badgeId: scenario.badge.id, personRef: registration.personRef, eventRef: registration.eventRef,
    registrationRef: registration.registrationId, ruleRef: sportsBadgeRuleRef,
    supportingEvidenceRefs: [presence.evidenceId, effort.evidenceId],
    title: scenario.badge.title, reason: scenario.badge.reason,
  };
}

export class SportsSeasonProvider implements SportsProvider {
  private readonly scenario: SportsSeasonScenario;
  private registration?: SportsRegistration;
  private evidence: SportsEvidence[] = [];
  private badge?: SportsBadge;

  constructor(scenario: SportsSeasonScenario, private readonly now: () => string = () => new Date().toISOString()) {
    const runnable = scenario.events.filter((event) => event.executable);
    if (scenario.person.membershipStatus !== "external" || scenario.contrastPerson.id === scenario.person.id ||
        runnable.length !== 1 || runnable[0].discipline !== "running" ||
        scenario.events.some((event) => event.seasonRef !== scenario.season.id) ||
        new Set(scenario.events.map((event) => event.id)).size !== scenario.events.length ||
        scenario.modalities.length !== 2 || new Set(scenario.modalities.map((item) => item.value)).size !== 2 ||
        scenario.modalities.some((item) => !modalities.includes(item.value)) ||
        scenario.efforts.length !== 3 || new Set(scenario.efforts.map((item) => item.value)).size !== 3 ||
        scenario.efforts.some((item) => !efforts.includes(item.value))) {
      throw new Error("Configuración incompatible con el corte local de Carrera.");
    }
    this.scenario = structuredClone(scenario);
  }

  async getSnapshot(): Promise<SportsSnapshot> {
    return structuredClone({
      scenario: this.scenario,
      criterion: { ruleRef: sportsBadgeRuleRef, explanation: "Inscripción aceptada, presencia simulada y esfuerzo autodeclarado para la misma persona y el mismo evento." },
      registration: this.registration,
      evidence: this.evidence,
      badge: this.badge,
      opportunity: this.badge ? {
        id: `invitation:${this.badge.registrationRef}`,
        personRef: this.badge.personRef, registrationRef: this.badge.registrationRef,
        badgeRef: this.badge.badgeId, kind: "club-invitation" as const, status: "available" as const,
      } : undefined,
      stage: this.badge ? "recognized" : this.evidence.length ? "presence-received" : this.registration ? "registered" : "available",
    });
  }

  async executeAction(action: SportsAction): Promise<SportsSnapshot> {
    if (!action || !["sports-register", "sports-check-in", "sports-effort"].includes(action.type)) {
      throw new Error("Esta acción no está disponible en la demo.");
    }
    if (action.personRef !== this.scenario.person.id) throw new Error("La acción no corresponde a este participante.");
    const event = this.scenario.events.find((item) => item.id === action.eventRef);
    if (!event?.executable || event.discipline !== "running") throw new Error("Elige el evento de Carrera disponible.");

    if (action.type === "sports-register") {
      if (this.registration) throw new Error("La inscripción ya está confirmada. Reinicia la demo para empezar de nuevo.");
      if (!modalities.includes(action.selectedModality)) throw new Error("Elige Social o Bienestar para confirmar la inscripción.");
      this.registration = {
        registrationId: `registration:${this.scenario.id}:1`,
        personRef: action.personRef, eventRef: action.eventRef,
        selectedModality: action.selectedModality as SportsModality, status: "accepted",
      };
      return this.getSnapshot();
    }

    const registration = this.registration;
    if (!registration) throw new Error("Confirma la inscripción antes de registrar la participación.");
    if (registration.registrationId !== action.registrationRef || registration.eventRef !== action.eventRef) {
      throw new Error("La acción no corresponde a esta inscripción y evento.");
    }
    if (action.type === "sports-check-in") {
      if (this.evidence.length) throw new Error("El check-in simulado ya está registrado.");
      const presence: SportsEvidence = {
        evidenceId: `${registration.registrationId}:presence`, kind: "presence",
        personRef: action.personRef, eventRef: action.eventRef, registrationRef: action.registrationRef,
        occurredAt: this.now(), source: "simulated-check-in", simulation: true,
      };
      this.evidence = [presence];
    } else {
      if (!this.evidence.some((item) => item.kind === "presence")) throw new Error("Registra primero el check-in simulado.");
      if (this.badge || this.evidence.some((item) => item.kind === "effort")) throw new Error("El esfuerzo ya está registrado.");
      if (!efforts.includes(action.level)) throw new Error("Elige un esfuerzo: suave, medio o intenso.");
      const effort: SportsEvidence = {
        evidenceId: `${registration.registrationId}:effort`, kind: "effort",
        personRef: action.personRef, eventRef: action.eventRef, registrationRef: action.registrationRef,
        occurredAt: this.now(), source: "participant-self-report", simulation: true, level: action.level as EffortLevel,
      };
      const nextEvidence = [...this.evidence, effort];
      const badge = recognize(registration, nextEvidence, this.scenario);
      if (!badge) throw new Error("No se puede establecer el reconocimiento con estos registros.");
      this.evidence = nextEvidence;
      this.badge = badge;
    }
    return this.getSnapshot();
  }

  async reset(): Promise<SportsSnapshot> {
    this.registration = undefined;
    this.evidence = [];
    this.badge = undefined;
    return this.getSnapshot();
  }
}
